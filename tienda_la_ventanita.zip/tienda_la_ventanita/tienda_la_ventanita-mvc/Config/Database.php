<?php
class Database 
{
    private $host = 'localhost';
    private $dbname = 'tienda_la_ventanita';
    private $username = 'root';
    private $password = '';
    public $conn;

    public function getConnection()
    {
        $this->conn = null;
        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->dbname, $this->username, 
            $this->password);
            $this->conn->exec ("set names utf8");
            echo "Conexión exitosa a la base de datos.";
        } catch (PDOException $exception) {
            echo "Error de conexión: " . $exception->getMessage();
        }
        return $this->conn;
    }
}

?>